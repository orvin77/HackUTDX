package com.example.guardababy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
