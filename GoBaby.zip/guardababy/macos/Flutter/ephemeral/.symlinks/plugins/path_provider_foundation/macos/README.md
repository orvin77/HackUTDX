This only contains symlinks to ../darwin, to support versions of Flutter
prior that don't include https://github.com/flutter/flutter/pull/115337.
Once the minimum Flutter version supported by this implementation is one that
includes that functionality, this directory should be removed.
